
var list1=document.querySelector('#li1');
var list2=document.querySelector('#li2');
var list3=document.querySelector('#li3');
var list4=document.querySelector('#li4');

var p1=document.querySelector('#p1');
var p2=document.querySelector('#p2');
var p3=document.querySelector('#p3');
var p4=document.querySelector('#p4');

var i1=document.querySelector('#i1');
var i2=document.querySelector('#i2');
var i3=document.querySelector('#i3');
var i4=document.querySelector('#i4');

var ip1=document.querySelector('#iplus1');
var ip2=document.querySelector('#iplus2');
var ip3=document.querySelector('#iplus3');
var ip4=document.querySelector('#iplus4');

ip1.addEventListener("click", showpara1);
function showpara1(){
    p1.style.display="block";
    p2.style.display="none";
    p3.style.display="none";
    p4.style.display="none";

    i1.style.display="inline";
    i2.style.display="none";
    i3.style.display="none";
    i4.style.display="none";
    
    ip1.style.display="none";
    ip2.style.display="inline";
    ip3.style.display="inline";
    ip4.style.display="inline";
    
}
ip2.addEventListener("click", showpara2);
function showpara2(){
    p1.style.display="none";
    p2.style.display="block";
    p3.style.display="none";
    p4.style.display="none";

    i1.style.display="none";
    i2.style.display="inline";
    i3.style.display="none";
    i4.style.display="none";
    
    ip1.style.display="inline";
    ip2.style.display="none";
    ip3.style.display="inline";
    ip4.style.display="inline";
    
}
ip3.addEventListener("click", showpara3);
function showpara3(){
    p1.style.display="none";
    p2.style.display="none";
    p3.style.display="block";
    p4.style.display="none";

    i1.style.display="none";
    i2.style.display="none";
    i3.style.display="inline";
    i4.style.display="none";
    
    ip1.style.display="inline";
    ip2.style.display="inline";
    ip3.style.display="none";
    ip4.style.display="inline";
    
}
ip4.addEventListener("click", showpara4);
function showpara4(){
    p1.style.display="none";
    p2.style.display="none";
    p3.style.display="none";
    p4.style.display="block";

    i1.style.display="none";
    i2.style.display="none";
    i3.style.display="none";
    i4.style.display="inline";
    
    ip1.style.display="inline";
    ip2.style.display="inline";
    ip3.style.display="inline";
    ip4.style.display="none";
    
}
i2.addEventListener("click",hidepara2);
function hidepara2(){
    p2.style.display="none";
    i2.style.display="none";
    ip2.style.display="inline";
}
i3.addEventListener("click",hidepara3);
function hidepara3(){
    p3.style.display="none";
    i3.style.display="none";
    ip3.style.display="inline";
}
i4.addEventListener("click",hidepara4);
function hidepara4(){
    p4.style.display="none";
    i4.style.display="none";
    ip4.style.display="inline";
}
i1.addEventListener("click",hidepara1);
function hidepara1(){
    p1.style.display="none";
    i1.style.display="none";
    ip1.style.display="inline";
}
div1=document.querySelector('.list1')
div2=document.querySelector('.list2')

ul1=document.querySelector('#ul1');
ul2=document.querySelector('#ul2');
ul3=document.querySelector('#ul3');
ul4=document.querySelector('#ul4');
ul1.style.border="5px solid blue";
ul1.style.padding="0px";
ul1.style.borderRadius="5px";
ul1.addEventListener("click",changediv1);
function changediv1(){
    ul1.style.border="5px solid blue";
    ul2.style.border="1px solid #ddd";
    ul1.style.borderRadius="5px";
    div1.style.display="inline"
    div2.style.display="none"
}
ul2.addEventListener("click",changediv2);
function changediv2(){
    ul2.style.border="5px solid blue";
    ul1.style.border="1px solid #ddd";
    ul2.style.borderRadius="5px";
    div2.style.display="inline"
    div1.style.display="none"
}
